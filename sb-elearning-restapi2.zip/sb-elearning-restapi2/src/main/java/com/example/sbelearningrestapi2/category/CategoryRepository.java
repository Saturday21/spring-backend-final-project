package com.example.sbelearningrestapi2.category;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface CategoryRepository extends JpaRepository<Category, Long> {
//    @Query(value = "select * from category", nativeQuery = true)
    @Query("select c from Category as c")
    List<Category> selectAllCategory();

    @Query("select c.name from Category as c")
    List<String> selectCategoryName();

    @Query("select c from Category as c where c.name = :name")
    List<Category> selectCategoryByName();

    @Query("select c from Category as c where c.name = ?1 and c.isDeleted = ?2")
    List<Category> selectCategoryByNameAndIsDeleted(String name, boolean isDeleted);

    @Transactional
    @Modifying
    @Query("""
        update Category as c
        set c.name = :newName
        where c.id = :id
    """)
    void updateCategoryName(Integer id, String newName);

    @Modifying
    @Query("""
        delete
        from Category as c
        where c.id = :id
    """)
    void removeById(Integer id);

}
