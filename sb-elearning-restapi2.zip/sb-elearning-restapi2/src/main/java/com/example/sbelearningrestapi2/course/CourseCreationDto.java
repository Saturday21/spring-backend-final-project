package com.example.sbelearningrestapi2.course;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record CourseCreationDto(
        @NotBlank
        String title,
        @NotBlank
        String descrption,
        @NotBlank
        String thumbnail,
        @NotNull
        Boolean isFree,
        @NotNull
        @Positive
        Integer categoryId,
        @NotNull
        Integer instructorId
) {
}
