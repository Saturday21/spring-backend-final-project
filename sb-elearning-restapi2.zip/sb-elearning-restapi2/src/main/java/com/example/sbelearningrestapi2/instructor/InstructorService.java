package com.example.sbelearningrestapi2.instructor;

import java.util.List;

public interface InstructorService {
    InstructorDto findById(Integer id);
    void deleteById(Integer id);
    InstructorDto editById(Integer id, InstructorEditionDto instructorEditionDto);
    void createNew(InstructorCreationDto instructorCreationDto);

    List<InstructorDto> search(String familyName, String givenName, String biography);

    InstructorDto findByIdAndNationalIdCard(Integer id, String nationalIdCard);
    List<InstructorDto> findList(String q);
}
