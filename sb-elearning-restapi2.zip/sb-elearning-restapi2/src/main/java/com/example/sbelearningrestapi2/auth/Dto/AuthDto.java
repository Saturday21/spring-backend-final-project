package com.example.sbelearningrestapi2.auth.Dto;

import lombok.Builder;

@Builder
public record AuthDto(
        String tokenType,
        String accessToken,
        String refreshToken
) {
}
