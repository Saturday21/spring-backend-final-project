package com.example.sbelearningrestapi2.instructor;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record InstructorCreationDto(@NotBlank String familyName,
                                    @NotBlank String givenName,
                                    @NotBlank
                                    @Size(min = 3, max = 20)
                                    String nationalIdCard,
                                    String biography
) {

}
