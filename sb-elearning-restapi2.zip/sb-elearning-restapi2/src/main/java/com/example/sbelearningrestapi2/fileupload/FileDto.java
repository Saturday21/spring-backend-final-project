package com.example.sbelearningrestapi2.fileupload;

import lombok.Builder;

@Builder
public record FileDto(
        String name,
        String extension,
        Long size,
        String uri,
        Boolean isDelete
) {
}
