package com.example.sbelearningrestapi2.instructor;

public record InstructorEditionDto(String familyName,
                                   String givenName,
                                   String biography
) {
}
