package com.example.sbelearningrestapi2.course;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.util.List;

@Mapper(componentModel = "spring")
public interface CourseMapper {

    CourseDto toCourseDto(Course course);
    List<CourseDto> toCourseListDto(List<Course> courses);
    @Mapping(source = "categoryId", target = "category.id")
    @Mapping(source = "instructorId", target = "instructor.id")
    Course fromCourseCreationDto(CourseCreationDto courseCreationDto);

    void fromCourseEditionDto(@MappingTarget Course course, CourseEditionDto courseCreationDto);
}
