package com.example.sbelearningrestapi2.role;

import java.util.List;

public interface RoleService {
    List<RoleDto> findAll();
    RoleDto findByName(String name);
}

