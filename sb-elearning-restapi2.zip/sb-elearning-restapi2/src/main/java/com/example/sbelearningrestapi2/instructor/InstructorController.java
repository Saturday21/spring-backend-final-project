package com.example.sbelearningrestapi2.instructor;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/instructors")
public class InstructorController {
    private final InstructorService instructorService;
    InstructorController(InstructorService instructorService) {
        this.instructorService = instructorService;
    }

    @GetMapping("/search")
    List<InstructorDto> search(@RequestParam(required = false, defaultValue = "") String familyName,
                               @RequestParam(required = false, defaultValue = "") String givenName,
                               @RequestParam(required = false, defaultValue = "") String biography) {
        return instructorService.search(familyName, givenName, biography);
    }

    // delete
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable Integer id) {
        instructorService.deleteById(id);
    }

    // edit
    @PutMapping("/{id}")
    public InstructorDto editById(@PathVariable Integer id, @RequestBody InstructorEditionDto instructorEditionDto) {
        return instructorService.editById(id, instructorEditionDto);
    }

    // create
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public void createNew(@RequestBody InstructorCreationDto instructorCreationDto) {
        System.out.println("Request Body: " + instructorCreationDto);
        instructorService.createNew(instructorCreationDto);
    }

    // search
    @GetMapping("/{id}/{nationalIdCard}")
    InstructorDto findByIdAndNationalIdCard(@PathVariable Integer id,
                           @PathVariable String nationalIdCard) {
        System.out.println("Path Variable ID: " + id);
        return instructorService.findByIdAndNationalIdCard(id, nationalIdCard);
    }

    @GetMapping("/{id}")
    InstructorDto findById(@PathVariable Integer id) {
        System.out.println("Path Variable ID: " + id);
        return instructorService.findById(id);
    }

    @GetMapping
    List<InstructorDto> findlist(@RequestParam (required = false, defaultValue = "") String q) {
            System.out.println("REQUEST PARAM: " + q);
            return instructorService.findList(q);
    }
}
