package com.example.sbelearningrestapi2.auth;

import com.example.sbelearningrestapi2.auth.Dto.*;
import jakarta.mail.MessagingException;
import org.springframework.security.core.Authentication;

import java.util.Map;

public interface AuthService {

    AuthDto refresh(RefreshTokenDto refreshTokenDto);

    AuthDto login(LoginDto loginDto);

    Map<String, Object> register(RegisterDto registerDto) throws MessagingException;

    Map<String, Object> verify(VerifyDto verifyDto);

}
