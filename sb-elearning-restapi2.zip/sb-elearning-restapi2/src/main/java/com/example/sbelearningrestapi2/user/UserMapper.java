package com.example.sbelearningrestapi2.user;

import com.example.sbelearningrestapi2.auth.Dto.RegisterDto;
import org.mapstruct.Mapper;
@Mapper(componentModel = "spring")
public interface UserMapper {

    User formUserCreationDto(UserCreationDto userCreationDto);

    UserCreationDto mapRegisterDtoToUserCreationDto(RegisterDto registerDto);

}
