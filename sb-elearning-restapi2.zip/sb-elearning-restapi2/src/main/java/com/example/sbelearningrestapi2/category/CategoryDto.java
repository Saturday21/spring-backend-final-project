package com.example.sbelearningrestapi2.category;

import lombok.Builder;

@Builder
public record CategoryDto(
        Long id,
        String name
) {
}