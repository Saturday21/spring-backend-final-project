package com.example.sbelearningrestapi2.course;


import java.util.List;

public interface CourseService {

    List<CourseDto> findList();

    CourseDto findById(Long id);

    void createNew(CourseCreationDto courseCreationDto);

    void editById(Long id, CourseEditionDto courseEditionDto);

    void disableById(Long id);
}
