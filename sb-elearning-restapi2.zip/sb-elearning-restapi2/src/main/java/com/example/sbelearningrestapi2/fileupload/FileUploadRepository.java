package com.example.sbelearningrestapi2.fileupload;

import java.io.File;
import java.util.Optional;

public interface FileUploadRepository {
     boolean deleteByName(String name);

    Optional<File> findByName(String name);
}
