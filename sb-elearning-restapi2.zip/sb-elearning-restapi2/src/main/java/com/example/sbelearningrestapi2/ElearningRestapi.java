package com.example.sbelearningrestapi2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElearningRestapi {

    public static void main(String[] args) {
        SpringApplication.run(ElearningRestapi.class, args);
    }

}
