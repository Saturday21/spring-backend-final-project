package com.example.sbelearningrestapi2.course;

import com.example.sbelearningrestapi2.category.CategoryDto;
import com.example.sbelearningrestapi2.instructor.InstructorDto;
import lombok.Builder;

@Builder
public record CourseDto(
        Long id,
        String title,
        String description,
        String thumbnail,
        Boolean isFree,
        CategoryDto category,
        InstructorDto instructor
) {
}
