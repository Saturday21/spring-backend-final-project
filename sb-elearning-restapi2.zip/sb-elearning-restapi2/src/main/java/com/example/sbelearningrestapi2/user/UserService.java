package com.example.sbelearningrestapi2.user;

public interface UserService {

    void createNew(UserCreationDto userCreationDto);
}
