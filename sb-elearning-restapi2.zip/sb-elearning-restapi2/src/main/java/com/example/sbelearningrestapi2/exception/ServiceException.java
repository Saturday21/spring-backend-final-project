package com.example.sbelearningrestapi2.exception;

import com.example.sbelearningrestapi2.base.BasedError;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;

import java.io.FileNotFoundException;
import java.time.LocalDateTime;

@RestControllerAdvice
public class ServiceException {
    @ExceptionHandler(ResponseStatusException.class)
    ResponseEntity<?> HandleService(ResponseStatusException e) {
        BasedError<?> basedError = BasedError.builder()
                .code(777)
                .timestamp(LocalDateTime.now())
                .message("Something went wrong")
                .errors(e.getMessage())
                .build();
        return ResponseEntity
                .status(e.getStatusCode())
                .body(basedError);
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(FileNotFoundException.class)
    BasedError<?> handelFileNotFound (FileNotFoundException e) {
        return BasedError.builder()
                .code(740)
                .timestamp(LocalDateTime.now())
                .message("Something went wrong")
                .errors(e.getLocalizedMessage())
                .build();
    }
}
